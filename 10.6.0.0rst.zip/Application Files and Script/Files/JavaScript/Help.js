﻿function showMod(ele) {
    minus = (ele + "minus");
    plus = (ele + "plus");

    sectionOpen(ele, 1);
    sectionOpen(minus, 1);
    sectionOpen(plus, 0);

}

function hideMod(ele) {
    minus = (ele + "minus");
    plus = (ele + "plus");

    sectionOpen(ele, 0);
    sectionOpen(minus, 0);
    sectionOpen(plus, 1);

}

function sectionOpen(menunum, state) {

    value = (state == 1) ? "block" : "none";
    document.all[menunum].style.display = value;

}