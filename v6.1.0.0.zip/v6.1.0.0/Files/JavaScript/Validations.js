﻿function SetSTRegnoMandatory(ddlVendorType, rdbServiceTaxable, txtStRegdNo, rdbCGTaxable, rdbInputTaxable) {
    if (ddlVendorType.value == "5") {
        if (rdbServiceTaxable.checked) {
            txtStRegdNo.style.backgroundColor = "#E5E5E5";
        }
        else {
            txtStRegdNo.style.backgroundColor = "White";
        }
    }
    if (!rdbCGTaxable.checked && !rdbInputTaxable.checked && !rdbServiceTaxable.checked)
        txtStRegdNo.style.backgroundColor = "White";
    else
        txtStRegdNo.style.backgroundColor = "#E5E5E5";
    return false;
}

function ChangeControlProperty(txtPanReference, lblPanRef, ddlPan, txtStRegdNo) {
    if (ddlPan.value == 'PAN') {
        txtPanReference.style.backgroundColor = "#E5E5E5";
        txtPanReference.value = "";
        lblPanRef.innerText = "PAN";
    }
    else {
        txtPanReference.style.backgroundColor = "White";
        txtPanReference.value = "";
        lblPanRef.innerText = "PAN Reference";
        txtStRegdNo.value = "";
    }
}
function ConvertToUC(ctrl) {
    ctrl.value = ctrl.value.toUpperCase();
}

function CarryPan(ddlPan, txtPanReference, txtStRegdNo) {
    if (ddlPan.value == 'PAN') {
        if (validatePANandClear(txtPanReference, "PAN", 10, true) == false) return false;
        else {
            txtStRegdNo.value = txtPanReference.value;
        }
    }
}

function validatePANandClear(ObjectName, ObjectCaption, MaxLength, Required) {
    var value = ObjectName.value;
    l = value.length;
    if (value != '') {
        for (var i = 0; i < 5; i++) {
            if ((value.charAt(i) >= 'A' && value.charAt(i) <= 'Z') || (value.charAt(i) >= 'a' && value.charAt(i) <= 'z'))
            { ; }
            else {
                alert("Enter a valid Character value In " + ObjectCaption + " Field(Ex: AAAAA1234A)")
                if (document.getElementsByName(ObjectName.name)) {
                    ObjectName.focus();
                    ObjectName.select();
                }
                return false;
            }
        }
        for (var i = 5; i < 9; i++) {
            if (value.charAt(i) >= '0' && value.charAt(i) <= '9') {
                ;
            }
            else {
                alert("Enter a valid Character value In  " + ObjectCaption + " Field(Ex: AAAAA1234A)")
                if (document.getElementsByName(ObjectName.name)) {
                    ObjectName.focus();
                    ObjectName.select();
                }
                return false;
            }
        }
        if ((value.charAt(9) >= 'A' && value.charAt(9) <= 'Z') || (value.charAt(9) >= 'a' && value.charAt(9) <= 'z')) {
            ;
        }
        else {
            alert("Enter a valid Character value In  " + ObjectCaption + " Field(Ex: AAAAA1234A)")
            if (document.getElementsByName(ObjectName.name)) {
                ObjectName.focus();
                ObjectName.select();
            }
            return false;
        }
    }
}

function ValidatePANType(ddlPan, txtPanReference, ddlConstitution, ddlStatus) {
    var value;
    if (ddlPan.value == 'PANAPPLIED' || ddlPan.value == 'PANINVALID' || ddlPan.value == 'PANNOTAVBL') {
        return true;
    }
    else if (ddlPan.value == 'PAN') {
        if (!ValidatePAN("PAN", txtPanReference, 10, true)) return false;
        var pan = txtPanReference.value;
        if (pan.substring(3, 4).toUpperCase() == "C") {
            if (ddlConstitution.selectedIndex == 1) {
                return confirm("Deductee Code selected is not proper \n If 4th Character of PAN entered is 'C' ,select Deductee Code as 'Companies'.\n If 4th Character of PAN entered is other than  'C' ,select Deductee Code as 'Other than Companies'.\n Do you want to continue?");
            }
        }
        else {
            if (ddlConstitution.selectedIndex == 0) {
                return confirm("Deductee Code selected is not proper \n If 4th Character of PAN entered is 'C' ,select Deductee Code as 'Companies'.\n If 4th Character of PAN entered is other than  'C' ,select Deductee Code as 'Other than Companies'.\n Do you want to continue?");
            }
        }
        var StatusText = ddlStatus.options[ddlStatus.selectedIndex].text;
        var valueOfPan = txtPanReference.value;
        var StatusSelected = "";
        if (valueOfPan.charAt(3).toUpperCase() == "F") {
            StatusSelected = "Firm"
        }
        else if (valueOfPan.charAt(3).toUpperCase() == "L") {
            StatusSelected = "Local Authority"
        }
        else if (valueOfPan.charAt(3).toUpperCase() == "P") {
            StatusSelected = "Personnal or Individual"
        }
        else if (valueOfPan.charAt(3).toUpperCase() == "H") {
            StatusSelected = "HUF"
        }

        if (StatusSelected != "") {

            if (valueOfPan.charAt(3).toUpperCase() == "P") {
                if (StatusText.charAt(0).toUpperCase() != "I") {
                    return alert("Fourth character of PAN Should match with the Status\n"
            + "     Fourth Character of PAN is " + valueOfPan.charAt(3).toUpperCase() + "\n" + "     Status must be " + StatusSelected)
                }
            }
            else if (StatusText.charAt(0).toUpperCase() != valueOfPan.charAt(3).toUpperCase()) {
                return alert("Fourth character of Pan Should match with the Status\n"
            + "     Fourth Character of PAN is " + valueOfPan.charAt(3).toUpperCase() + "\n" + "     Status must be " + StatusSelected)
            }
        }

    }
    else {
        alert("Select Pan Type");
        return false;
    }
    return true;
}

function ValidatePAN(objCaption, objName, maxLen, isReq) {
    var value = objName.value;
    if (isReq) {
        if (value.trim().length == 0) {
            alert("Specify PAN");
            objName.focus();
            return false;
        }
    }
    if (value.trim().length > 0) {
        for (var i = 0; i < value.length; i++) {
            if (value.charAt(i) == ' ') {
                if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                    alert(objCaption + " does not \nallow Blank Spaces. (Ex: AAAAA1234A OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
                else
                    alert(objCaption + " does not \nallow Blank Spaces. (Ex: AAAAA1234A)");
                objName.focus();
                return false;
            }
        }

        if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER') {
            if (value.trim().toUpperCase() == 'GOVERNMENT' || value.trim().toUpperCase() == 'NONRESDENT' || value.trim().toUpperCase() == 'OTHERVALUE') {
                return true;
            }
        }
        for (var i = 0; i < 5; i++) {
            if ((value.charAt(i) >= 'A' && value.charAt(i) <= 'Z') || (value.charAt(i) >= 'a' && value.charAt(i) <= 'z'))
            { ; }
            else {
                if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                    alert("Specify a valid character value in\n" + objCaption + ".(Ex: AAAAA1234A OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
                else
                    alert("Specify a valid Character value in\n" + objCaption + " Field. (Ex: AAAAA1234A)")
                if (document.getElementsByName(objName.name)) {
                    objName.focus();
                }
                return false;
            }
        }
        for (var i = 5; i < 9; i++) {
            if (value.charAt(i) >= '0' && value.charAt(i) <= '9') {
                ;
            }
            else {
                if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                    alert("Specify a valid character value in\n" + objCaption + ".(Ex: AAAAA1234A OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
                else
                    alert("Specify a valid Character value in\n" + objCaption + " Field. (Ex: AAAAA1234A)")
                objName.focus();
                return false;
            }
        }
        if ((value.charAt(9) >= 'A' && value.charAt(9) <= 'Z') || (value.charAt(9) >= 'a' && value.charAt(9) <= 'z')) {
            ;
        }
        else {
            if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                alert("Specify a valid character value in\n" + objCaption + ".(Ex: AAAAA1234A OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
            else
                alert("Specify a valid Character value in\n" + objCaption + " Field. (Ex: AAAAA1234A)")
            objName.focus();
            return false;
        }
        if (value.charAt(3).toUpperCase() != 'P' && value.charAt(3).toUpperCase() != 'H' && value.charAt(3).toUpperCase() != 'C' && value.charAt(3).toUpperCase() != 'J' && value.charAt(3).toUpperCase() != 'F' && value.charAt(3).toUpperCase() != 'A' && value.charAt(3).toUpperCase() != 'T' && value.charAt(3).toUpperCase() != 'B' && value.charAt(3).toUpperCase() != 'L' && value.charAt(3).toUpperCase() != 'G') {
            //alert("Specify valid PAN.");
            if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                alert("Specify valid PAN OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
            else
                alert("Specify valid PAN.");
            objName.focus();
            return false;
        }
        return true;
    }
}

function ValidateCountry(ddlState, ddlCountry) {
    if (ddlState.value == "99") {
        if (ddlCountry.value != "1") {
            if (!ValidateDropDown(ddlCountry,"Country")) return false;
            if (ddlCountry.value == "1") {
                alert("For the state 'Foreign' country should be other than 'India'");
                ddlCountry.focus();
                return false;
            }
            else {
                return true;
            }
        }
        else {
            alert("State is selected as foreign,country should be other than India");
            return false;
        }
    }
    else {
        if (ddlCountry.value != "113") {
            alert("Country should be India");
            return false;
        }
        else {
            return true;
        }
    }
}


function ValidateTDSSection(lstSelectedTDS, ddlTDSSection) {
    if (lstSelectedTDS.options.length == 0) {
        ddlTDSSection.selectedIndex = 0;
        ddlTDSSection.focus();
        alert("Select TDS Section");
        return false;
    }
    return true;
}

function ValidateService(lstSelectedService, ddlServiceSection) {
    if (lstSelectedService.options.length == 0) {
        ddlServiceSection.selectedIndex = 0;
        ddlServiceSection.focus();
        alert("Select Service ");
        return false;
    }
    return true;
}

function ValidateInput(lstSelectedInput, ddlInputSection) {
    if (lstSelectedInput.options.length == 0) {
        ddlInputSection.selectedIndex = 0;
        ddlInputSection.focus();
        alert("Select Inputs ");
        return false;
    }
    return true;
}

function ValidateCapitalGoods(lstSelectedCG, ddlCGSection) {
    if (lstSelectedCG.options.length == 0) {
        ddlCGSection.selectedIndex = 0;
        ddlCGSection.focus();
        alert("Select Capital Goods ");
        return false;
    }
    return true;
}

function ValidateSTRegdNo(rdbCGTaxable, rdbInputTaxable, rdbServiceTaxable, txtStRegdNo) {
    if ((rdbCGTaxable.checked || rdbInputTaxable.checked || rdbServiceTaxable.checked)) {
        alert("Specify ST Registration No.");
        txtStRegdNo.focus();
        return false;
    }
    if (txtStRegdNo.value != "" && txtStRegdNo.value.length != 15) {
        alert("StRegdNo Should be of 15 characters");
        txtStRegdNo.focus();
        return false;
    }
    return true;
}

function Validations(ddlVendorType, hdnIsinputDedMade) {
    if (ddlVendorType.value == "5") {
        if (hdnIsinputDedMade.value > 0) {
            alert("Since some Input Capital Deductions have been made.\n you can't change the Vendor type to Service Provider.");
            ddlVendorType.focus();
            return false;
        }
        return true;
    }
    return true;
}

function EnableDisableCountry(ddlState, ddlCountry) {
    if (ddlState.value == "99") {
        ddlCountry.selectedIndex = 0;
        ddlCountry.disabled = false;
    }
    else {
        ddlCountry.selectedIndex = 112;
        ddlCountry.disabled = true;
    }
}

function ValidateCertificateNumber(objName, objCaption, maxLen, isReq) {
    var value = objName.value;
    if (isReq) {
        if (value.trim().length == 0) {
            alert("Specify " + objCaption);
            objName.focus();
            return false;
        }
        else if (value.trim().length != maxLen) {
            alert("Certificate number should be of length 10.");
            objName.focus();
            return false;
        }
    }
    var pattern = /^[0-9]{4}[a-zA-Z]{2}[0-9]{3}[a-zA-Z]{1}$/;
    var matchArray = value.match(pattern);
    if (matchArray == null) {
        alert("Specify valid certificate number.(Ex: 1234AA123A)");
        objName.focus();
        return false;
    }

    return true;
}